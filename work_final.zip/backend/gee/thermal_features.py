from __future__ import annotations
import ee
import pandas as pd
from backend.gee.ee_init import init_ee
from backend.gee.thermal_sampler import get_thermal_period
from backend.processing.grid import make_square_geometry, make_point_grid

def _celsius(image):
    return image.select("ST_B10").multiply(0.00341802).add(149.0).subtract(273.15).rename("land_surface_temperature_c")

def get_grid_thermal_features(aoi, scale_m=10, start_date="2024-01-01", end_date="2026-01-01"):
    init_ee()
    radius=max(float(aoi["radius_m"]),200.0)
    geometry=make_square_geometry(float(aoi["latitude"]),float(aoi["longitude"]),radius)
    points=make_point_grid(geometry,int(scale_m))
    image=_celsius(get_thermal_period(start_date,end_date,geometry))
    fc=image.reduceRegions(collection=points,reducer=ee.Reducer.mean(),scale=30,tileScale=2).getInfo()
    rows=[]
    for f in fc.get("features",[]):
        p=f.get("properties") or {}; cid=p.get("cell_id"); v=p.get("land_surface_temperature_c")
        if cid and v is not None:
            rows.append({"cell_id":cid,"land_surface_temperature_c":float(v)})
    df=pd.DataFrame(rows)
    if df.empty: raise RuntimeError("No valid Landsat thermal pixels were returned.")
    # Local contrast is computed from the sampled surface temperature field.
    med=df["land_surface_temperature_c"].median(); mad=(df["land_surface_temperature_c"]-med).abs().median()
    scale=max(1.4826*float(mad),0.25)
    df["thermal_robust_anomaly"]=((df["land_surface_temperature_c"]-med).abs()/scale).clip(0,5)/5.0
    return df
