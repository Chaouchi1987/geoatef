import ee

from backend.gee.ee_init import (
    init_ee
)

from backend.gee.thermal_sampler import (
    get_thermal_period
)


def get_neighborhood_temperature(

    lat,
    lon,

    start_date,
    end_date,

    radius_m=100

):

    init_ee()

    center = ee.Geometry.Point(
        [lon, lat]
    )

    ring = center.buffer(
        radius_m
    )

    image = get_thermal_period(
        start_date,
        end_date
    )

    thermal = image.select(
        "ST_B10"
    )

    values = thermal.reduceRegion(

        reducer=ee.Reducer.mean(),

        geometry=ring,

        scale=30,

        maxPixels=1e9

    )

    info = values.getInfo()

    raw_temp = info.get(
        "ST_B10"
    )

    if raw_temp is None:

        return None

    temp_celsius = (

        raw_temp * 0.00341802

        + 149.0

        - 273.15

    )

    return round(
        temp_celsius,
        2
    )