from backend.gee.slope import get_slope

print(
    get_slope(
        lat=35.376,
        lon=7.760
    )
)