from backend.gee.ndwi import get_ndwi

print(
    get_ndwi(
        lat=35.376,
        lon=7.760,
        radius=1000
    )
)