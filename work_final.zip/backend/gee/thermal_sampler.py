from __future__ import annotations
import ee
from backend.gee.ee_init import init_ee

def get_thermal_period(start_date, end_date, geometry=None):
    init_ee()
    collections=[]
    for dataset in ["LANDSAT/LC08/C02/T1_L2", "LANDSAT/LC09/C02/T1_L2"]:
        c=ee.ImageCollection(dataset)
        if geometry is not None:
            c=c.filterBounds(geometry)
        c=c.filterDate(start_date,end_date)
        collections.append(c)
    collection=collections[0].merge(collections[1])
    def mask(image):
        qa=image.select("QA_PIXEL")
        clear=qa.bitwiseAnd(1<<3).eq(0).And(qa.bitwiseAnd(1<<4).eq(0)).And(qa.bitwiseAnd(1<<1).eq(0))
        sat=image.select("QA_RADSAT").eq(0)
        return image.updateMask(clear.And(sat))
    return collection.map(mask).median()
