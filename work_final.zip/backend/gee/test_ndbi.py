from backend.gee.ndbi import get_ndbi

print(
    get_ndbi(
        lat=35.376,
        lon=7.760,
        radius=1000
    )
)